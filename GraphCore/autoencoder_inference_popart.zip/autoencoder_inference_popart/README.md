## Quick start guide

Execute:

```
# Install tf2onnx
pip3 install -r requirements.txt

# Convert model.pb to model.onnx
python -m tf2onnx.convert --saved-model saved_model.pb --output model.onnx

# Run to measure to measure synthetic throughput on a single IPU
python autoencoder_128chan_ipu_infer.py

```

Sample output of `autoencoder_128chan_ipu_infer.py`:

```
Starting inference loop, will run for 10 iterations
Loop 0 complete.
Took 33.912 seconds at 1887.3 img/sec
Loop 1 complete.
Took 34.281 seconds at 1866.9 img/sec
Loop 2 complete.
Took 34.317 seconds at 1865.0 img/sec
Loop 3 complete.
Took 33.995 seconds at 1882.6 img/sec
Loop 4 complete.
Took 33.923 seconds at 1886.7 img/sec
Loop 5 complete.
Took 34.472 seconds at 1856.6 img/sec
Loop 6 complete.
Took 34.185 seconds at 1872.2 img/sec
Loop 7 complete.
Took 34.192 seconds at 1871.8 img/sec
Loop 8 complete.
Took 34.051 seconds at 1879.5 img/sec
Loop 9 complete.
Took 34.024 seconds at 1881.1 img/sec
Average throughput is: 1875.0 at batch size 64
```
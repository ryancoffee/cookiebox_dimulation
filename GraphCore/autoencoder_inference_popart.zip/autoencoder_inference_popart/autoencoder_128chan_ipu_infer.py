# SLAC AutoEncoder PopART Inference Script
# Author: Brad Turcott
# Date: April 13th, 2021

import numpy as np
import popart
import time 
import sys, os

# Configuration Parameters
NUM_IPUs = 1
BATCHES_PER_STEP = 1000
BS=64
N_SAMPLES = BS*BATCHES_PER_STEP
N_EPOCHS = 10 

# Setup file path & executable save path (to avoid future recompiles)
fp = os.path.dirname(sys.argv[0])
os.environ['POPLAR_LOG_LEVEL'] = 'INFO'

# Start timer
start = time.time()

# Load model from onnx file (assumes model is in same dir as python script)
builder = popart.Builder(fp + "model.onnx")

# Exctract input and output layer Ids from graph
inputTensorIds = builder.getInputTensorIds()
outputTensorIds = builder.getOutputTensorIds()
input_1 = inputTensorIds[0]
permute = outputTensorIds[0]

# Configure input shape based on selected batch size (must be determined ahead of run-time)
inputShapeInfo = popart.InputShapeInfo()
inputShapeInfo.add(input_1, popart.TensorInfo("FLOAT", [BS, 128, 128, 1]))
proto = builder.getModelProto()

# Setup device manager to automatically acquire an available IPU device after the IPU executable has been compiled.
connectionType = popart.DeviceConnectionType.OnDemand
device = popart.DeviceManager().acquireAvailableDevice(NUM_IPUs, connectionType=connectionType)

# Setup anchors (graph outputs) and PopART dataflow (description of graph exection)
anchors = {permute: popart.AnchorReturnType("All")}
dataFlow = popart.DataFlow(BATCHES_PER_STEP, anchors)

# Setup session options
sessOptions = popart.SessionOptions()
sessOptions.enableEngineCaching = True
sessOptions.cachePath = fp + "engine_cache/"

# Setup inference session
session = popart.InferenceSession(
    fnModel = proto, 
    dataFlow = dataFlow, 
    deviceInfo = device,
    inputShapeInfo = inputShapeInfo,
    userOptions=sessOptions)
print("ONNX model loaded, inference session configured, starting graph compilation...")

# Compile engine (i.e., IPU executable)
session.prepareDevice()
print("Graph compilation complete.")

# Create buffers to receive results from the execution and load pre-trained weights from host
anchors = session.initAnchorArrays()
session.weightsFromHost()

# Generate synthetic input data and setup input/output buffers using PyStepIO
# Supplemental information included here: https://docs.graphcore.ai/projects/popart-user-guide/en/latest/executing.html
data_a = np.random.rand(N_SAMPLES, 128, 128, 1).astype(np.float32)
stepio = popart.PyStepIO({input_1: data_a}, anchors)

# Synthetic inference runs
print("Warm up...")
session.run(stepio)
duration = time.time() - start
print("Warm up run complete.")
print("Duration: {:.3f} seconds".format(duration))
throughput = []
print("Starting inference loop, will run for {} iterations".format(N_EPOCHS))
for i in range(N_EPOCHS):
    start = time.time()
    session.run(stepio)
    stop = time.time()
    duration = stop - start
    fps = N_SAMPLES/duration
    throughput.append(fps)
    print("Loop {} complete.".format(i))
    print("Took {:.3f} seconds at {:.1f} img/sec".format(duration, fps))
avg_throughput = np.mean(throughput)
print("Average throughput is: {:.1f} at batch size {}".format(avg_throughput, BS))
